import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCJNkftSBB6tSJ_AA4zgBEFJhUS2iz-OwY",
            authDomain: "to-do-jf1sa8.firebaseapp.com",
            projectId: "to-do-jf1sa8",
            storageBucket: "to-do-jf1sa8.appspot.com",
            messagingSenderId: "322702556447",
            appId: "1:322702556447:web:cd81aa89d0924b5793042a"));
  } else {
    await Firebase.initializeApp();
  }
}
