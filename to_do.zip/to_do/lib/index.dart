// Export pages
export '/login/login_widget.dart' show LoginWidget;
export '/tasks/tasks_widget.dart' show TasksWidget;
export '/onboarding/onboarding_widget.dart' show OnboardingWidget;
export '/details/details_widget.dart' show DetailsWidget;
export '/forgot_password/forgot_password_widget.dart' show ForgotPasswordWidget;
export '/completed/completed_widget.dart' show CompletedWidget;
