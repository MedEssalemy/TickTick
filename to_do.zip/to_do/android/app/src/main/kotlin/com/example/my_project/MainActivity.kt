package com.mycompany.todo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
